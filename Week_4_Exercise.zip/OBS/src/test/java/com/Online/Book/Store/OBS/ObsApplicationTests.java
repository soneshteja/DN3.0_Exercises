package com.Online.Book.Store.OBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObsApplicationTests {

	@Test
	void contextLoads() {
	}

}
