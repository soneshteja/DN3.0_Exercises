package com.Online.Book.Store.OBS.controller;

import com.Online.Book.Store.OBS.entity.BookEntity;
import com.Online.Book.Store.OBS.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;


    @GetMapping("/{id}")
    public ResponseEntity<BookEntity> getBookById(@PathVariable Long id) {
        BookEntity book = bookService.getBookById(id);
        if (book != null) {
            return new ResponseEntity<>(book, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping
    public ResponseEntity<List<BookEntity>> getBooksByTitleAndAuthor(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author
    ) {
        List<BookEntity> books = bookService.getBooksByTitleAndAuthor(title, author);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }


}