package com.raks.BookstoreAPI;

import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test") 
public class ApplicationTests {

    @Test
    void contextLoads() {
    }
}
